numeros = [3, 7, 12, 18, 25, 30, 45, 60, 75, 90]
print("Primer número:", numeros[0])
print("Último número:", numeros[-1])
print("Número en la posición 5:", numeros[4])
print("Lista en orden inverso:", numeros[::-1])