numeros=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
suma=0
for x in numeros:
    suma+=x
print("la suma de los elementos de la lista es:",suma)
print("el promedio de los elementos de la lista es:",suma/len(numeros))
print("numero mayor de la lista:",max(numeros))
print("numero menor de la lista:",min(numeros))
