números=[1,2,2,3,4,4,4,5,6,6,6,6]
for n in set(números):
    print(f"el número {n} aparece {números.count(n)} veces en la lista")
