persona = {
   "nombre": "Ana",
   "edad": 25,
   "profesion": "Ingeniera"
}
persona["ciudad"] = "Medellin"
persona["edad"] = 26
del persona["profesion"]

print("dicionario final:",persona)
