frutas=["manzana", "pera", "banana", "uva",]
frutas.append("naranja")
frutas.insert(1,"fresa")
frutas.remove("banana")
print("lista resultante:",frutas)

