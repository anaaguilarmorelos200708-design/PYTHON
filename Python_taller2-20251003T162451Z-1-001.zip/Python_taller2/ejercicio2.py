#Escribe un programa que pida un número entero positivo n y calcule la suma de todos los números pares entre 1 y n.
n = int(input("Ingresa un número entero positivo n: "))
if n <= 0:
    print("Por favor, ingresa un número entero positivo.")
else:
    suma_pares = 0
    for i in range(2, n + 1, 2):
        suma_pares += i

    print(f"La suma de los números pares entre 1 y {n} es: {suma_pares}")

