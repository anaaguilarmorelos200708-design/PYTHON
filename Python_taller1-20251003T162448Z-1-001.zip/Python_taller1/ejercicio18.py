'''python'''
num1 = float(input("ingrese un numero: "))
num2 = float(input("ingrese un numero: "))
if num1 > num2:
    print("el primero es mayor")
elif num1 < num2:
    print("el segundo es menor")
else:
    print("son iguales")
             