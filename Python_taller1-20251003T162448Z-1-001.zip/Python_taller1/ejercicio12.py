'''python'''
frase = "los campistas necesitan practicar mucho con python!, por eso, haran bastantes ejercicios!"
contar = frase.lower().count(" ")
print ("la cantidad de espacios en blanco es:",contar) 