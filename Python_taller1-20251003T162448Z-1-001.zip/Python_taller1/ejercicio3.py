'''python'''
salario = 1623500  #int
salud = salario*0.04 #float
print (f" la salud que debe pagar la persona es:{salud}")