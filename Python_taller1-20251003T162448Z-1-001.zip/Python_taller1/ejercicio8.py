'''python'''
apellido = "Aguilar_Morelos"
minuscula = str.lower(apellido)
mayuscula = str.upper(apellido)
print ("el apellido en mayuscula es:",mayuscula)