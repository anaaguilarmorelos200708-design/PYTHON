#radio_circulo = diametro/2
#area_circulo = 3.14 * (radio_circulo**2)
diametro = 30
radio_circulo = diametro/2
area_circulo = 3.14 * (radio_circulo** 2)
print(area_circulo)