'''python''' 
import math
angulo = 90 #se asigna el valor 90 a la variable angulo
hipotenusa = 20
opuesto = 10
adyacente = 5
seno = opuesto/hipotenusa
coseno = adyacente/hipotenusa
tangente = opuesto/adyacente 
print ("el angulo de seno coseno tangente es:",angulo)