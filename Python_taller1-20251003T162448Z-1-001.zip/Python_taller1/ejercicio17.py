nombre = input("Ingrese el nombre: ")
limpio = " ".join(nombre.split()).strip().lower()
print("EP­ es 'Bon Jovi Ernesto'" if limpio == "bon jovi ernesto" else "No es 'Bon Jovi Ernesto'")