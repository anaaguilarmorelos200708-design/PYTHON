'''python'''
frase = "los campistas necesitan practicar mucho con python!, por eso, haran bastantes ejercicios!"
print (frase.split()) 