'''python'''
frase = float(input("ingrese una frase: "))
print (frase.lower().count("a"))