'''python'''
palabra = input("ingrese una palabra: ")
letra = input("ingrese una letra: ")
if not letra:
    print("letra no valida.")
else:
    posi =palabra.find(letra)
    if posi == -1:
        print("la letra no aparece en la palabra.")
    else:
        print(f"posicion (1-based) = {posi +1}")