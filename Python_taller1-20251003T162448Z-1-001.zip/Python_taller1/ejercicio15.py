'''python'''
edad = 20 
mayor = 20 > 18
print ("Mayor a 18 es:",mayor) 