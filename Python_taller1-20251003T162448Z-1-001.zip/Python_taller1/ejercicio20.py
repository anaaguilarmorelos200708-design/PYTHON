'''python'''
salario = int(input("ingrese el salario: "))
salainte = salario*10 + salario*30/100
if salainte:
    print ("salario integral")
print ("el salario integral es: ",salainte)