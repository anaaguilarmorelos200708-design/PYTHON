'''python'''
base = 50 #se asigna el valor 50 a la variable base
altura = 40.5 #se asigna el valo 40.5 a la variable altura
area = base*altura/2
#se imprime el area del triangulo
print  (area)