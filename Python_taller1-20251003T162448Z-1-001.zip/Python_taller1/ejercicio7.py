'''python'''
nombre = "ANA_AGUILAR"
mayuscula = nombre.upper()
minuscula = nombre.lower()
print ("el nombre en minuscula es:",minuscula)