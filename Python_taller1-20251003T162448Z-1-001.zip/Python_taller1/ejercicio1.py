lado = 70 #se asigna el valor 70 a la variable lado
area = lado*lado #se calcula el área del cuadrado
#se imprime el área del cuadrado
print(f"El área del cuadrado es: {area}")  #forma 1 de imprimir
print("El área del cuadrado es:", area) #forma 2 de imprimir

