'''python'''
edad = int(input("ingrese la edad: "))
print("mayor de edad" if edad >= 18 else "menor de edad")