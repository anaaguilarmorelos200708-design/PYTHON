'''python'''
nombrecom ="Ana_Rebeca_Aguilar_Morelos"
str.capitalize(nombrecom)
print ("el nombrecom en str.capitalize es:",str.capitalize(nombrecom))